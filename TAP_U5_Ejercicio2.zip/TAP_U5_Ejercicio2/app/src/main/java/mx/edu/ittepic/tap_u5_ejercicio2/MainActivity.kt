package mx.edu.ittepic.tap_u5_ejercicio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Message
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        menuprincipal.setOnItemClickListener { parent, view, position, id ->
            when(position){
                0 -> {
                    val ventana2 = Intent(this, MainActivity2::class.java)
                    startActivity(ventana2)
                }
                1 -> {
                    val ventana3 = Intent(this, MainActivity3::class.java)
                    startActivity(ventana3)
                }
                2 -> {
                    val ventana4 = Intent(this, MainActivity4::class.java)
                    startActivity(ventana4)
                }
                3 -> {
                    val ventana5 = Intent(this, MainActivity5::class.java)
                    startActivity(ventana5)
                }
                4 -> {message()}
                5 -> {cerrar()}
            }
        }
    }

    fun message(){
        AlertDialog.Builder(this)
            .setTitle("ATENCIÓN")
            .setMessage("(C) DECHOS RESERVADOS ALEXIS DIAZ\n COMPOSTELA NAYARIT")
            .setPositiveButton("OK", {d, i -> d.dismiss()})
            .show()
    }

    fun cerrar(){
        finish()
    }
}
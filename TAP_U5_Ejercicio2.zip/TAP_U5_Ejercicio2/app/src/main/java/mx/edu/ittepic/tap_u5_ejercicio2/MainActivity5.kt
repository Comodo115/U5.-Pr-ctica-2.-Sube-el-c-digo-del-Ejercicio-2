package mx.edu.ittepic.tap_u5_ejercicio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main5.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.Exception

class MainActivity5 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main5)

        abrir.setOnClickListener {
            if(memoriaInterna()){
                AlertDialog.Builder(this)
                    .setTitle("EXITO")
                    .setMessage("Se recupero la data")
                    .show()
            }else{
                AlertDialog.Builder(this)
                    .setTitle("ERROR")
                    .setMessage("No se recupero la data")
                    .show()
            }
        }

        regresar.setOnClickListener {
            finish()
        }
    }

    fun memoriaInterna() : Boolean{
        var data = ""

        try{
            var flujoEntrada = BufferedReader(InputStreamReader(openFileInput("Almacen.txt")))

            data = flujoEntrada.readLine()
            textView2.setText(data)
            flujoEntrada.close()
            return true
        }catch (io:Exception){
            AlertDialog.Builder(this)
                .setTitle("ERROR")
                .setMessage("No se recupero la data")
                .show()
        }

        return false
    }
}
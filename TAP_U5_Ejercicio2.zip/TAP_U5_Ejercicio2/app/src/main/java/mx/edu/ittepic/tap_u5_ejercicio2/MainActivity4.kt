package mx.edu.ittepic.tap_u5_ejercicio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main4.*
import java.io.OutputStream
import java.io.OutputStreamWriter

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        Guardar.setOnClickListener {
            if(guardarEnMemoriaInterna(contenidoarchivo.text.toString())){
                contenidoarchivo.setText("")
                AlertDialog.Builder(this)
                    .setTitle("Exito")
                    .setMessage("Se guardo el archivo correctamente")
                    .setPositiveButton("OK", {d,i -> d.dismiss()})
                    .show()
            }
        }

        Regresar.setOnClickListener {
            finish()
        }
    }

    fun guardarEnMemoriaInterna(content:String) : Boolean{
        if(content.isEmpty()){
            Toast.makeText(this, "Debes poner un enunciado",Toast.LENGTH_LONG)
                .show()
            return false
        }

        try{

            var FlujoSalida = OutputStreamWriter(openFileOutput("Almacen.txt", MODE_PRIVATE))
            FlujoSalida.write(content)
            FlujoSalida.flush()
            FlujoSalida.close()
            return true

        }catch (io:Exception){
            AlertDialog.Builder(this)
                .setTitle("ERROR")
                .setMessage("No se pudo guardar el archivo")
                .show()
        }
        return false

    }
}